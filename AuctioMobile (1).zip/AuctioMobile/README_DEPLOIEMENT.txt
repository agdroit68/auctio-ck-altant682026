════════════════════════════════════════════════════════════
 AUCTIO MOBILE — Guide d'installation (GitHub Pages + iPhone)
════════════════════════════════════════════════════════════

CE QUE C'EST
  App de saisie live des ventes aux encheres, 100% hors-ligne.
  Les donnees restent dans le telephone. En fin de vente, elle
  genere le PV Excel (format comptable) a envoyer par mail,
  puis a importer dans Auctio PC ("Importer Excel").

─────────────────────────────────────────────
 ETAPE 1 — Mettre l'app en ligne (une seule fois, ~10 min)
─────────────────────────────────────────────
 1. Creer un compte gratuit sur github.com (bouton "Sign up").
    Utiliser un e-mail generique (gmail...), pas besoin de plus.
 2. Une fois connecte : bouton "+" en haut a droite -> "New repository".
    - Repository name : un nom difficile a deviner, ex.  auctio-ck-7x2m
    - Cocher "Public" (obligatoire pour la version gratuite)
    - Cliquer "Create repository".
 3. Sur la page du depot : lien "uploading an existing file".
    Glisser-deposer TOUS les fichiers de ce dossier :
      index.html, xlsx.min.js, sw.js, manifest.webmanifest,
      icon-180.png, icon-512.png
    Puis bouton vert "Commit changes".
 4. Onglet "Settings" -> menu "Pages" (colonne de gauche) :
    - Source : "Deploy from a branch"
    - Branch : "main" + "/ (root)" -> "Save".
 5. Attendre 1-2 minutes, recharger la page : l'adresse s'affiche :
      https://VOTRE-NOM.github.io/auctio-ck-7x2m/
    C'est l'adresse de l'app.

─────────────────────────────────────────────
 ETAPE 2 — Installer sur l'iPhone (~1 min)
─────────────────────────────────────────────
 1. Sur l'iPhone, ouvrir l'adresse dans SAFARI (pas Chrome).
 2. Bouton Partager (carre avec fleche) -> "Sur l'ecran d'accueil"
    -> "Ajouter".
 3. Une icone "Auctio" apparait : l'app s'ouvre en plein ecran
    et fonctionne ensuite SANS AUCUN RESEAU (mode avion compris).
 A faire sur chaque telephone concerne (le votre + la comptable).

─────────────────────────────────────────────
 ETAPE 3 — Activer le code d'acces (~30 s)
─────────────────────────────────────────────
 Au premier lancement, toucher le cadenas en haut a droite
 de l'accueil (ou le bouton "Definir" du bandeau jaune) :
 choisir un code (4 chiffres minimum), le confirmer.
 Le code sera demande a chaque ouverture de l'app : sans lui,
 rien ne s'affiche. A activer sur chaque telephone.
 (Pour le changer ou le retirer : meme cadenas, code actuel requis.)

─────────────────────────────────────────────
 UTILISATION LE JOUR D'UNE VENTE
─────────────────────────────────────────────
 1. La veille : creer la "vente pre-live" (nom, date, lieu,
    commissaire) — ces infos remplissent le PV automatiquement.
 2. Pendant la vente (onglet Saisie) :
    n° lot -> designation -> n° adjudicataire -> montant -> Adjuger.
    Le n° de lot suivant se pre-remplit tout seul.
    Bouton "Invendu" pour les lots non adjuges.
    Toucher une ligne de la bande pour la corriger/supprimer.
 3. A la caisse (onglet Acheteurs) : completer nom, adresse,
    regle + mode (VIR/ESP/CB/CHQ) de chaque numero.
 4. En fin de vente (onglet Cloture & PV) :
    "Generer & envoyer le PV (.xlsx)" -> choisir Mail -> envoyer
    a l'adresse de la comptable / de l'etude.
 5. A l'etude : recuperer le fichier joint, puis dans Auctio PC :
    ouvrir la vente -> "Importer Excel" -> les factures se generent
    (statuts regles et modes repris automatiquement).

─────────────────────────────────────────────
 IMPORTANT
─────────────────────────────────────────────
 - Envoyer le PV DES LA FIN DE LA VENTE : tant qu'il n'est pas
   envoye, la saisie n'existe que dans le telephone.
 - La "Sauvegarde de secours (.json)" (onglet Cloture) cree une
   copie complete de la vente, partageable par mail egalement.
 - Mise a jour de l'app : redeposer les nouveaux fichiers sur
   GitHub (meme manipulation qu'a l'etape 1.3) ; l'app se met a
   jour a sa prochaine ouverture avec du reseau.
 - Aucune donnee de vente n'est sur GitHub : seul le "formulaire
   vide" y est heberge. Les saisies restent dans le telephone
   et ne circulent que par les mails que vous envoyez.
